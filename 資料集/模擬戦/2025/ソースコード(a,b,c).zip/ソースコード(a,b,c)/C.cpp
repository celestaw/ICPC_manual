#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int i = 0; i < (n); i++)
#define ll long long 
int main(){
    while(1){
        ll int n,k;
        cin >> n >> k;
        
        if(n == 0 && k == 0){
            break;
        }
        vector<int> a;

        for(int i=1;i*i<=n;i++){
            if(n % i == 0){
                a.push_back(i);
                if(i != n / i){
                    a.push_back(n / i);
                }
            }
        }
        ll int sum = 0;
        rep(i,a.size()){
            sum += a[i];
        }
        if(sum*k% n == 0){
            cout << "Yes" << endl;
        }
        else{
            cout << "No" << endl;
        }
    }
    return 0;
}