#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int i = 0; i < (n); i++)
int main()
{
    while(1){
        int n,m;
        cin >> n >> m;
        if(n == 0 && m == 0){
            break;
        }
        int a[m],b[m];
        rep(i,m){
            cin >> a[i] >> b[i];
        }
        int count[n];
        for(int i = 0;i<n;i++){
            count[i] = 0;
        }
        for(int i = m-1;i>=0;i--){
            count[a[i]-1]++;
            if(count[b[i]-1] != 0){
                count[b[i]-1]--;
            }
        }
        int sum = 0;
        for(int i = 0;i<n;i++){
            sum += count[i];
        }
        cout << sum << endl;
    }
    return 0;
}