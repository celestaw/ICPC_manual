#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int i = 0; i < (n); i++)
int main()
{
    while (1)
    {
        int n;
        cin >> n;
        if(n == 0)
        {
            break;
        }
        vector<int> a(100000,1);
        int x;
        for (int i = 0; i < n; i++)
        {
            cin >> x;
            a.at(x-1) = 0;
        }
        
        for (int i = 0; i < 100000; i++)
        {
            if (a.at(i) == 1)
            {
                cout << i + 1 << endl;
                break;
            }
        }
    }

    return 0;
}